

function entryPoint(){
	console.log('Init script.');
}
